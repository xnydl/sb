using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SmartBot.Database;
using SmartBot.Plugins.API;

namespace SmartBotAPI.Mercenaries
{
    public class MercProf : MercProfile
    {
		private Random _rd = new Random();
		
		public int NextInt(int max, int min = 0)
        {
            _rd = new Random();
            return _rd.Next(min, max);
        }
		
        public List<LettuceAction> HandleCombatPhase(MercBoard board)
        {
			int waitingTime = NextInt(40,25);
			Bot.Log("Waiting " + waitingTime + "s...");
			Task.Delay(waitingTime * 1000).Wait();
            
			var autoRandomActions = new List<LettuceAction>();
			foreach(var merc in board.MercsFriend)
			{
				autoRandomActions.Add(new LettuceAction(merc.Id, -1 , -1, true));
			}
            return autoRandomActions;
        }

        public List<MercCard> HandlePlayMercPhase(MercBoard board)
        {
            int mercToPlay = 3 - board.MercsFriend.Count;
            return board.Hand.Take(mercToPlay).ToList();
        }
    }
}