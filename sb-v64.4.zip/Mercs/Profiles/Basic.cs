using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartBotAPI.Mercenaries
{
    public class MercProf : MercProfile
    {
        public List<LettuceAction> HandleCombatPhase(MercBoard board)
        {
			var autoRandomActions = new List<LettuceAction>();
			foreach(var merc in board.MercsFriend)
			{
				autoRandomActions.Add(new LettuceAction(merc.Id, -1 , -1, true));
			}
            return autoRandomActions;
        }

        public List<MercCard> HandlePlayMercPhase(MercBoard board)
        {
            int mercToPlay = 3 - board.MercsFriend.Count;
            return board.Hand.Take(mercToPlay).ToList();
        }
    }
}