using SmartBot.Plugins.API;
using SmartBotAPI.Duels;
using System;
using System.Collections.Generic;
using System.Linq;
using SmartBot.Database;

namespace SmartBot.Plugins
{
    public class BasicDuelProfile : DuelProfile
    {
        private Dictionary<Card.CClass,int> HeroPriorities = new Dictionary<Card.CClass, int>()
        {
            {Card.CClass.DEMONHUNTER, 1},
            {Card.CClass.DRUID, 6},
            {Card.CClass.HUNTER, 2},
            {Card.CClass.MAGE, 9},
            {Card.CClass.PALADIN, 10},
            {Card.CClass.PRIEST, 3},
            {Card.CClass.SHAMAN, 7},
            {Card.CClass.ROGUE, 8},
            {Card.CClass.WARLOCK, 4},
            {Card.CClass.WARRIOR, 5}
        };

        public Card.Cards HandleHeroRequest(List<Card.Cards> options)
        {
            var orderedOptions = options.OrderBy(x => HeroPriorities[CardTemplate.LoadFromId(x).Class]).ToList();

            return orderedOptions[0];
        }

        public Card.Cards HandleHeroPowerRequest(List<Card.Cards> options)
        {
            return options[0];
        }

        public Card.Cards HandleSatchelRequest(List<Card.Cards> options)
        {
            return options[0];
        }

        public Card.Cards HandleTreasureRequest(Card.CClass heroClass, List<Card.Cards> options)
        {
			Bot.Log(heroClass.ToString());
            return options[0];
        }

        public DuelLootOption HandleLootRequest(Card.CClass heroClass, List<DuelLootOption> options)
        {
			Bot.Log(heroClass.ToString());
            return options[0];
        }

        public List<Card.Cards> HandleDeckRequest(Card.CClass heroClass)
        {
            //Bot.Log("HandleDeckRequest : " + heroClass);
            var basicDeck = GetBasicDeckForClass(heroClass);

            if (basicDeck.Any(x => PlayerData.Collection.ContainsKey(x) == false))
            {
                Bot.Log("YOU ARE MISSING CARDS TO BUILD A BASIC DUEL DECK!");
                throw new Exception("YOU ARE MISSING CARDS TO BUILD A BASIC DUEL DECK!");
            }

            return basicDeck;
        }

        private List<Card.Cards> GetBasicDeckForClass(Card.CClass heroClass)
        {
            switch (heroClass)
            {
                case Card.CClass.DEMONHUNTER:
                    return DHBaseDeck;
                case Card.CClass.DRUID:
                    return DruidBaseDeck;
                case Card.CClass.HUNTER:
                    return HunterBaseDeck;
                case Card.CClass.MAGE:
                    return MageBaseDeck;
                case Card.CClass.PALADIN:
                    return PaladinBaseDeck;
                case Card.CClass.PRIEST:
                    return PriestBaseDeck;
                case Card.CClass.ROGUE:
                    return RogueBaseDeck;
                case Card.CClass.SHAMAN:
                    return ShamanBaseDeck;
                case Card.CClass.WARLOCK:
                    return WarlockBaseDeck;
                case Card.CClass.WARRIOR:
                    return WarriorBaseDeck;

            }

            return new List<Card.Cards>();
        }

        private List<Card.Cards> DHBaseDeck = new List<Card.Cards>()
        {
            Cards.TwinSlice,
            Cards.BladeDance,
            Cards.ChaosStrike,
            Cards.AldrachiWarblades,
            Cards.EyeBeam,
            Cards.Magehunter,
            Cards.Marrowslicer,
            Cards.GlaiveboundAdept,
            Cards.WrathspikeBrute,
            Cards.CycleofHatred,
            Cards.HulkingOverfiend,
            Cards.AncientVoidHound,
            Cards.DemonCompanion,
            Cards.ManafeederPanthara,
            Cards.Wandmaker
        };

        private List<Card.Cards> DruidBaseDeck = new List<Card.Cards>()
        {
            Cards.NatureStudies,
            Cards.Wrath,
            Cards.WildGrowth,
            Cards.Swipe,
            Cards.Starfall,
            Cards.TwilightRunner,
            Cards.Nourish,
            Cards.SurvivaloftheFittest,
            Cards.LightningBloom,
            Cards.SpeakerGidra,
            Cards.LakeThresher,
            Cards.SludgeBelcher,
            Cards.TeachersPet,
            Cards.GuardianAnimals,
            Cards.MedivhtheGuardian
        };

        private List<Card.Cards> HunterBaseDeck = new List<Card.Cards>()
        {
            Cards.CarrionStudies,
            Cards.ExplosiveTrap,
            Cards.FreezingTrap,
            Cards.KindlyGrandmother,
            Cards.AnimalCompanion,
            Cards.BloatedPython,
            Cards.EaglehornBow,
            Cards.KillCommand,
            Cards.UnleashtheHounds,
            Cards.AdorableInfestation,
            Cards.DemonCompanion,
            Cards.HauntedCreeper,
            Cards.MadScientist,
            Cards.NerubianEgg,
            Cards.TeachersPet
        };

        private List<Card.Cards> MageBaseDeck = new List<Card.Cards>()
        {
            Cards.BabblingBook,
            Cards.LabPartner,
            Cards.CramSession,
            Cards.SorcerersApprentice,
            Cards.ArcaneIntellect,
            Cards.Firebrand,
            Cards.Fireball,
            Cards.ArchmageAntonidas,
            Cards.BrainFreeze,
            Cards.DevolvingMissiles,
            Cards.PrimordialStudies,
            Cards.WandThief,
            Cards.Wandmaker,
            Cards.JandiceBarov,
            Cards.RasFrostwhisper
        };

        private List<Card.Cards> PaladinBaseDeck = new List<Card.Cards>()
        {
            Cards.Avenge,
            Cards.Redemption,
            Cards.GoodyTwoShields,
            Cards.RallyingBlade,
            Cards.BlessingofKings,
            Cards.Consecration,
            Cards.TruesilverChampion,
            Cards.BlessingofAuthority,
            Cards.TirionFordring,
            Cards.MadScientist,
            Cards.GiftofLuminance,
            Cards.LordBarov,
            Cards.Feugen,
            Cards.Stalagg,
            Cards.DevoutPupil
        };

        private List<Card.Cards> PriestBaseDeck = new List<Card.Cards>()
        {
            Cards.DraconicStudies,
            Cards.FrazzledFreshman,
            Cards.InnerFire,
            Cards.KulTiranChaplain,
            Cards.PowerWordFeast,
            Cards.DarkCultist,
            Cards.CabalAcolyte,
            Cards.HolyNova,
            Cards.PriestoftheFeast,
            Cards.CabalShadowPriest,
            Cards.WaveofApathy,
            Cards.NetherspiteHistorian,
            Cards.Wandmaker,
            Cards.CrimsonHothead,
            Cards.TwilightDrake
        };

        private List<Card.Cards> RogueBaseDeck = new List<Card.Cards>()
        {
            Cards.Backstab,
            Cards.Shadowstep,
            Cards.DeadlyPoison,
            Cards.SecretPassage,
            Cards.Eviscerate,
            Cards.EdwinVanCleef,
            Cards.SI7Agent,
            Cards.VulperaToxinblade,
            Cards.BrainFreeze,
            Cards.TourGuide,
            Cards.WandThief,
            Cards.Steeldancer,
            Cards.CuttingClass,
            Cards.DoctorKrastinov,
            Cards.JandiceBarov
        };

        private List<Card.Cards> ShamanBaseDeck = new List<Card.Cards>()
        {
            Cards.TotemicMight,
            Cards.EarthShock,
            Cards.LightningBolt,
            Cards.DiligentNotetaker,
            Cards.MaelstromPortal,
            Cards.RuneDagger,
            Cards.StormforgedAxe,
            Cards.FeralSpirit,
            Cards.InstructorFireheart,
            Cards.LightningStorm,
            Cards.Bloodlust,
            Cards.TotemGoliath,
            Cards.LightningBloom,
            Cards.DevolvingMissiles,
            Cards.TourGuide
        };

        private List<Card.Cards> WarlockBaseDeck = new List<Card.Cards>()
        {
            Cards.DemonicStudies,
            Cards.FlameImp,
            Cards.MalchezaarsImp,
            Cards.Soulfire,
            Cards.Voidwalker,
            Cards.BonewebEgg,
            Cards.SchoolSpirits,
            Cards.ShadowlightScholar,
            Cards.SilverwareGolem,
            Cards.Voidcaller,
            Cards.VoidDrinker,
            Cards.DeskImp,
            Cards.RaiseDead,
            Cards.SpiritJailer,
            Cards.SoulShear
        };

        private List<Card.Cards> WarriorBaseDeck = new List<Card.Cards>()
        {
            Cards.AthleticStudies,
            Cards.Armorsmith,
            Cards.Execute,
            Cards.Rampage,
            Cards.FrothingBerserker,
            Cards.ShieldBlock,
            Cards.DeathsBite,
            Cards.KorkronElite,
            Cards.ReapersScythe,
            Cards.Brawl,
            Cards.GrommashHellscream,
            Cards.Troublemaker,
            Cards.Rattlegore,
            Cards.Coerce,
            Cards.LordBarov
        };

    }
}
