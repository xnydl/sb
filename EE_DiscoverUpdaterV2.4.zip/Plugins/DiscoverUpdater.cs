﻿using System;
using System.IO;
using System.Diagnostics;
using SmartBot.Plugins.API;
using System.ComponentModel;

namespace SmartBot.Plugins
{
	[Serializable]
	public class bPluginDataContainer : PluginDataContainer
	{
		//Plug-in description
		[Category("Plugin")]
		[DisplayName("Description")]
		public string Description
		{
			get
			{
				return "Auto update of discovery files on injection\r\nby Evil-Eyes V2.4";
			}
		}

		//Auto start on injection
		[Category("Test")]
		[Browsable(true)]
		[DisplayName("Update test")]
		public bool update { get; set; }

		//Init vars
		public bPluginDataContainer()
		{
			Name = "DiscoverUpdater";
		}
	}
	public class bPlugin : Plugin
	{
		//Variables
		private string filePath = Directory.GetCurrentDirectory() + @"\EEDiscoverUpdater.exe";

		/* --------------- Execute EvilEyes Discover Updater -------------- */

		//On data container update
		public override void OnDataContainerUpdated()
		{
			if (!DataContainer.Enabled)
				return;

			Process.Start(filePath);
			Bot.Log("[PLUGIN] -> EvilEyesDiscovery: Updating Files ...");
			Data().update = false;
		}


		//On injection event
		public override void OnInjection()
		{
			if (!DataContainer.Enabled)
				return;

			Process.Start(filePath);
			Bot.Log("[PLUGIN] -> EvilEyesDiscovery: Updating Files ...");
		}

		private bPluginDataContainer Data()
		{
			return (bPluginDataContainer)DataContainer;
		}
	}
}
